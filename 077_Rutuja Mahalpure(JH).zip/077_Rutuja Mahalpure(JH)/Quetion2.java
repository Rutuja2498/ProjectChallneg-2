
import java.util.Scanner;

class LL{
	static class node{
		private int data;
		private node next;
		public node(int val){
			data = val;
			next = null;
		}
	}
	node head;
	LL(){
		head = null;
	}
	
	void addLast(int val){
		node newNode = new node(val);
		if(head==null){
			head=newNode;
		}
		else{
			node trav=head;
			while(trav.next!=null){
				trav=trav.next;
			}
			trav.next=newNode;
		}
	}
	
	void display(){
		node trav=head;
		while(trav!=null){
			System.out.print("\t"+trav.data);
			trav=trav.next;
		}
		System.out.println();
	}
	
	void pairWiseSwap()
    {
        node temp = head; 
        while (temp != null && temp.next != null) {
            int var = temp.data;
            temp.data = temp.next.data;
            temp.next.data = var;
            temp = temp.next.next;
        }
    }
}


class Quetion2{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		LL l =new LL();
		int choice,val;
		
		do{
			System.out.println("\n0.Exit \n1.addLast \n2. Display  \n3.Swap");
			choice=sc.nextInt();
			switch(choice){
				case 1:
					System.out.println("Enter data");
					val=sc.nextInt();
					l.addLast(val);
				break;
				case 2:
					System.out.println("List:");
					l.display();
				break;
				case 3:
					l.pairWiseSwap();
			}
			
		}while(choice!=0);
	}
}